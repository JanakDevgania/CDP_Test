//
//  SceneDelegate.swift
//  CDP-TMDB
//
//  Created by Techsevin on 08/07/25.
//

import UIKit
import UserNotifications

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        window = UIWindow(windowScene: windowScene)

        let moviesVC = UINavigationController(rootViewController: MovieListViewController())
        moviesVC.tabBarItem = UITabBarItem(title: "Movies", image: UIImage(systemName: "film"), tag: 0)

        let searchVC = UINavigationController(rootViewController: SearchViewController())
        searchVC.tabBarItem = UITabBarItem(title: "Search", image: UIImage(systemName: "magnifyingglass"), tag: 1)

        let favVC = UINavigationController(rootViewController: FavouritesViewController())
        favVC.tabBarItem = UITabBarItem(title: "Favourites", image: UIImage(systemName: "star"), tag: 2)

        let tabBarController = UITabBarController()
        tabBarController.viewControllers = [moviesVC, searchVC, favVC]
        
        UITabBar.appearance().tintColor = .label  
        UITabBar.appearance().unselectedItemTintColor = .gray

        window?.rootViewController = tabBarController
        window?.makeKeyAndVisible()
        

        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, _ in
            if granted {
                print("✅ Notifications granted")
            } else {
                print("❌ Notifications denied")
            }
        }

    }
    
   



}
