//
//  APIManager.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import Foundation
import Alamofire

class APIManager {
    static let shared = APIManager()
    private let apiKey = "f0b5551de413381f66eb787a022435af"
    private let baseURL = "https://api.themoviedb.org/3"
    
    func fetchNowPlaying(page: Int = 1, completion: @escaping (Result<MovieResponse, Error>) -> Void) {
        let url = "\(baseURL)/movie/now_playing?api_key=\(apiKey)&language=en-US&page=\(page)"
        
        AF.request(url).responseDecodable(of: MovieResponse.self) { response in
            switch response.result {
            case .success(let movieResponse):
                completion(.success(movieResponse))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    
    func searchMovies(query: String, completion: @escaping (Result<[Movie], Error>) -> Void) {
        let url = "\(baseURL)/search/movie"
        let parameters: Parameters = [
            "api_key": apiKey,
            "language": "en-US",
            "query": query,
            "page": 1,
            "include_adult": false
        ]
        
        AF.request(url, parameters: parameters).responseDecodable(of: MovieResponse.self) { response in
            switch response.result {
            case .success(let movieResponse):
                completion(.success(movieResponse.results))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func getMovieDetails(movieId: Int, completion: @escaping (Result<MovieDetails, Error>) -> Void) {
        let url = "\(baseURL)/movie/\(movieId)?api_key=\(apiKey)&language=en-US"
        
        AF.request(url).responseDecodable(of: MovieDetails.self) { response in
            switch response.result {
            case .success(let movieDetails):
                completion(.success(movieDetails))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func getMovieById(movieId: Int, completion: @escaping (Result<Movie, Error>) -> Void) {
        let url = "\(baseURL)/movie/\(movieId)?api_key=\(apiKey)&language=en-US"

        AF.request(url).responseDecodable(of: Movie.self) { response in
            switch response.result {
            case .success(let movie):
                completion(.success(movie))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    

    
}
