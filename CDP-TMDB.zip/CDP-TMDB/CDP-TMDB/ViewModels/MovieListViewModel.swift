//
//  MovieListViewModel.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

class MovieListViewModel {
    
    private(set) var movies: [Movie] = []
    private var currentPage = 1
    private var totalPages = 1
     var isLoading = false

    func fetchMovies(reset: Bool = false, completion: @escaping () -> Void) {
        guard !isLoading else { return }
        isLoading = true

        if reset {
            currentPage = 1
            totalPages = 1
            movies = []
        }

        APIManager.shared.fetchNowPlaying(page: currentPage) { result in
            self.isLoading = false
            switch result {
            case .success(let response):
                self.totalPages = response.total_pages
                self.movies.append(contentsOf: response.results)
                self.currentPage += 1
            case .failure(let error):
                print("Pagination error: \(error)")
            }
            completion()
        }
    }


    func shouldLoadMore(index: Int) -> Bool {
        return index == movies.count - 1 && currentPage <= totalPages && !isLoading
    }
}
