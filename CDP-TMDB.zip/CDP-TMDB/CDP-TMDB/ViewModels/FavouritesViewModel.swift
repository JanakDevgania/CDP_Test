//
//  FavouritesViewModel.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import Foundation

class FavouritesViewModel {
    var movies: [Movie] = []

    func loadFavourites() {
        movies = FavouriteManager.shared.getFavourites()
    }

    func remove(at index: Int) {
        let movie = movies[index]
        FavouriteManager.shared.remove(movie: movie)
        movies.remove(at: index)
    }
}
