//
//  SearchViewModel.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import Foundation

class SearchViewModel {
    var movies: [Movie] = []

    func search(for query: String, completion: @escaping () -> Void) {
        APIManager.shared.searchMovies(query: query) { result in
            switch result {
            case .success(let movies):
                self.movies = movies
            case .failure(let error):
                print("Search error: \(error)")
                self.movies = []
            }
            completion()
        }
    }
}
