//
//  SearchViewController.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import UIKit

class SearchViewController: UIViewController, UITableViewDataSource,UITableViewDelegate, UISearchBarDelegate {
    
    private let tableView = UITableView()
    private let searchBar = UISearchBar()
    private let viewModel = SearchViewModel()
    private var searchTimer: Timer?

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Search"
        view.backgroundColor = .systemBackground
        navigationController?.navigationBar.tintColor = .black
        setupSearchBar()
        setupTableView()
        
        hideKeyboardWhenTappedAround()
        
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder() // ✅ Dismiss the keyboard
        guard let query = searchBar.text, !query.isEmpty else { return }
        
    }

    private func setupSearchBar() {
        searchBar.placeholder = "Search movies..."
        searchBar.delegate = self
        navigationItem.titleView = searchBar
    }
    

    private func setupTableView() {
        tableView.frame = view.bounds
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(MovieTableViewCell.self, forCellReuseIdentifier: MovieTableViewCell.identifier)
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 120
        view.addSubview(tableView)
    }

    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchTimer?.invalidate()
        
        guard !searchText.trimmingCharacters(in: .whitespaces).isEmpty else {
            viewModel.movies = []
            tableView.reloadData()
            return
        }

        // Start new timer
        searchTimer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: false) { [weak self] _ in
            self?.viewModel.search(for: searchText) {
                DispatchQueue.main.async {
                    self?.tableView.reloadData()
                }
            }
        }
    }
    

    // MARK: - TableView DataSource

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.movies.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableViewCell.identifier, for: indexPath) as? MovieTableViewCell else {
            return UITableViewCell()
        }
        let movie = viewModel.movies[indexPath.row]
        cell.configure(with: movie)
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movie = viewModel.movies[indexPath.row]
        let detailVC = MovieDetailViewController()
        detailVC.movie = movie

        // Hide back button title
        let backItem = UIBarButtonItem()
        backItem.title = ""
        navigationItem.backBarButtonItem = backItem

        navigationController?.pushViewController(detailVC, animated: true)
    }


}
extension SearchViewController {
    func hideKeyboardWhenTappedAround() {
           let tap = UITapGestureRecognizer(target: self, action: #selector(SearchViewController.dismissKeyboard))
           tap.cancelsTouchesInView = false
        navigationController?.view.addGestureRecognizer(tap)
       }
       
       @objc func dismissKeyboard() {
           navigationController?.view.endEditing(true)
       }
}
