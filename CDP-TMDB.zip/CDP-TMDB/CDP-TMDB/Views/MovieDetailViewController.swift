//
//  MovieDetailViewController.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import UIKit
import SDWebImage

class MovieDetailViewController: UIViewController {

    var movie: Movie?

    let scrollView = UIScrollView()
    let contentView = UIView()

    let titleLabel = UILabel()
   
    let genreLabel = UILabel()
    let releaseDateLabel = UILabel()
    let ratingLabel = UILabel()
    let posterImageView = UIImageView()
    let overviewLabel = UILabel()


    private let favouriteButton: UIButton = {
        let button = UIButton(type: .system)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 28)
        button.tintColor = .systemRed
        return button
    }()


    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        navigationItem.backButtonTitle = ""
        navigationController?.navigationBar.tintColor = .black

        setupUI()
        if let movie = movie {
            fetchMovieDetails(id: movie.id)
        }
        
        guard let movie = movie else { return }
        favouriteButton.setImage(RealmManager.shared.isFavourite(movie)
                                  ? UIImage(systemName: "heart.fill")
                                  : UIImage(systemName: "heart"), for: .normal)
        favouriteButton.addTarget(self, action: #selector(favouriteTapped), for: .touchUpInside)

        
        scrollView.showsVerticalScrollIndicator = false

    }
    
    @objc private func favouriteTapped() {
        guard let movie = movie else { return }
        if RealmManager.shared.isFavourite(movie) {
            RealmManager.shared.removeFromFavourites(movie)
            favouriteButton.setImage(UIImage(systemName: "heart"), for: .normal)
        } else {
            RealmManager.shared.addToFavourites(movie)
            favouriteButton.setImage(UIImage(systemName: "heart.fill"), for: .normal)
        }
        print("Added to favourites:", movie.title)

    }
    
    private func scheduleFavoriteNotification(for movieTitle: String) {
        let content = UNMutableNotificationContent()
        content.title = "⭐️ Added to Favorites"
        content.body = "\(movieTitle) has been added to your favorites."
        content.sound = .default

        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request)
    }


    private func setupUI() {
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scrollView)
        scrollView.addSubview(contentView)

        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            
            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.widthAnchor.constraint(equalTo: scrollView.widthAnchor)
        ])
        
        titleLabel.font = .boldSystemFont(ofSize: 22)
        titleLabel.textAlignment = .left
        titleLabel.numberOfLines = 0

        genreLabel.font = .systemFont(ofSize: 16)
        genreLabel.textColor = .secondaryLabel

        releaseDateLabel.font = .systemFont(ofSize: 16)
        releaseDateLabel.textColor = .secondaryLabel

        ratingLabel.font = .systemFont(ofSize: 16)
        ratingLabel.textColor = .systemYellow

        posterImageView.contentMode = .scaleAspectFit
        posterImageView.clipsToBounds = true
        posterImageView.translatesAutoresizingMaskIntoConstraints = false
        posterImageView.heightAnchor.constraint(equalToConstant: 400).isActive = true

        overviewLabel.numberOfLines = 0
        overviewLabel.font = .systemFont(ofSize: 16)
        overviewLabel.textColor = .label
        
        let headerStack = UIStackView(arrangedSubviews: [titleLabel, favouriteButton])
        headerStack.axis = .horizontal
        headerStack.alignment = .center
        headerStack.distribution = .equalSpacing

        let stack = UIStackView(arrangedSubviews: [
            posterImageView,
            headerStack,
            genreLabel,
            releaseDateLabel,
            ratingLabel,
            
            overviewLabel
        ])
        stack.axis = .vertical
        stack.spacing = 12
        stack.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(stack)

        NSLayoutConstraint.activate([
            stack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 20),
            stack.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16),
            stack.bottomAnchor.constraint(lessThanOrEqualTo: contentView.bottomAnchor , constant: -20)
        ])


    }
    
   

    private func fetchMovieDetails(id: Int) {
        APIManager.shared.getMovieDetails(movieId: id) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let details):
                    self.updateUI(with: details)
                case .failure(let error):
                    print("Failed to fetch details: \(error)")
                }
            }
        }
    }

    private func updateUI(with details: MovieDetails) {
        title = details.title
        titleLabel.text = details.title
        genreLabel.text = "Genres: " + details.genres.map { $0.name }.joined(separator: ", ")
        releaseDateLabel.text = "Release Date: \(details.release_date)"
        ratingLabel.text = "⭐️ Rating: \(details.vote_average)/10"
        overviewLabel.text = details.overview
        if let url = details.posterURL {
            posterImageView.sd_setImage(with: url, placeholderImage: UIImage(systemName: "film"))
        }
    }
    
    

}
