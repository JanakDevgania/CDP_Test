//
//  MovieListViewController.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import UIKit

class MovieListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    let tableView = UITableView()
    let viewModel = MovieListViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Movies"
        view.backgroundColor = .systemBackground
        
        navigationItem.backButtonTitle = ""
        navigationController?.navigationBar.tintColor = .black
            setupTableView()
            tableView.rowHeight = UITableView.automaticDimension
            tableView.estimatedRowHeight = 120
            tableView.prefetchDataSource = self
            tableView.showsVerticalScrollIndicator = false
        viewModel.fetchMovies(reset: true) {
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
        }
    }

    func setupTableView() {
        tableView.frame = view.bounds
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(MovieTableViewCell.self, forCellReuseIdentifier: MovieTableViewCell.identifier)
        tableView.register(SpinnerTableViewCell.self, forCellReuseIdentifier: SpinnerTableViewCell.identifier)
        
        view.addSubview(tableView)
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.movies.count + (viewModel.isLoading ? 1 : 0)
    }


    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row < viewModel.movies.count {
            let cell = tableView.dequeueReusableCell(withIdentifier: MovieTableViewCell.identifier, for: indexPath) as! MovieTableViewCell
            let movie = viewModel.movies[indexPath.row]
            cell.configure(with: movie)
            cell.selectionStyle = .none
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: SpinnerTableViewCell.identifier, for: indexPath) as! SpinnerTableViewCell
            return cell
        }
    }

    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movie = viewModel.movies[indexPath.row]
            let detailVC = MovieDetailViewController()
            detailVC.movie = movie
            
            navigationItem.backButtonTitle = ""

            navigationController?.pushViewController(detailVC, animated: true)
    }

}

extension MovieListViewController: UITableViewDataSourcePrefetching {
    func tableView(_ tableView: UITableView, prefetchRowsAt indexPaths: [IndexPath]) {
        guard let maxRow = indexPaths.map({ $0.row }).max() else { return }
        if viewModel.shouldLoadMore(index: maxRow) {
            viewModel.fetchMovies {
                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            }
        }
    }

}
