//
//  MovieDetails.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import Foundation

struct MovieDetails: Decodable {
    let id: Int
    let title: String
    let overview: String
    let poster_path: String?
    let genres: [Genre]
    let release_date: String
    let vote_average: Double

    var posterURL: URL? {
        if let path = poster_path {
            return URL(string: "https://image.tmdb.org/t/p/w500\(path)")
        }
        return nil
    }
}

struct Genre: Decodable {
    let id: Int
    let name: String
}
