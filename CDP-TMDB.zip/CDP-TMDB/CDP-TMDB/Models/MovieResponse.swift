//
//  MovieResponse.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

struct MovieResponse: Decodable {
    let page: Int
    let total_pages: Int
    let results: [Movie]
}
