//
//  MovieObject.swift
//  CDP-TMDB
//
//  Created by Techsevin on 10/07/25.
//

import RealmSwift

class MovieObject: Object {
    @Persisted(primaryKey: true) var id: Int
    @Persisted var title: String = ""
    @Persisted var posterPath: String?
    @Persisted var releaseDate: String?
    @Persisted var voteAverage: Double
    
    convenience init(from movie: Movie) {
        self.init()
        self.id = movie.id
        self.title = movie.title
        self.posterPath = movie.poster_path
        self.releaseDate = movie.release_date
        self.voteAverage = movie.vote_average ?? 0.0
    }
    
    func toMovie() -> Movie {
        return Movie(id: id,
                     title: title,
                     poster_path: posterPath,
                     release_date: releaseDate,
                     vote_average: voteAverage)
    }
}
