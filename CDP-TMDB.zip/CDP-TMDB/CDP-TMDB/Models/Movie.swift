//
//  Movie.swift
//  CDP-TMDB
//
//  Created by Techsevin on 08/07/25.
//

import Foundation

struct Movie: Codable, Equatable {
    let id: Int
    let title: String
    let poster_path: String?
    let release_date: String?
    let vote_average: Double?

    var posterURL: URL? {
        guard let path = poster_path else { return nil }
        return URL(string: "https://image.tmdb.org/t/p/w500\(path)")
    }
}







