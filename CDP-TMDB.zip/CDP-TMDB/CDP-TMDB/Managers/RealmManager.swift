//
//  RealmManager.swift
//  CDP-TMDB
//
//  Created by Techsevin on 10/07/25.
//

import RealmSwift

class RealmManager {
    static let shared = RealmManager()
    private let realm = try! Realm()
    private init() {}

    func addToFavourites(_ movie: Movie) {
        let obj = MovieObject(from: movie)
        try? realm.write { realm.add(obj, update: .modified) }
    }

    func removeFromFavourites(_ movie: Movie) {
        guard let obj = realm.object(ofType: MovieObject.self, forPrimaryKey: movie.id) else { return }
        try? realm.write { realm.delete(obj) }
    }

    func isFavourite(_ movie: Movie) -> Bool {
        realm.object(ofType: MovieObject.self, forPrimaryKey: movie.id) != nil
    }

    func getAllFavourites() -> [Movie] {
        realm.objects(MovieObject.self).map { $0.toMovie() }
    }
}
