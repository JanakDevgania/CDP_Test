//
//  FavouritesManager.swift
//  CDP-TMDB
//
//  Created by Techsevin on 09/07/25.
//

import Foundation

class FavouriteManager {
    static let shared = FavouriteManager()
    private let key = "favouriteMovies"

    func save(movie: Movie) {
        var saved = getFavourites()
        if !saved.contains(where: { $0.id == movie.id }) {
            saved.append(movie)
            saveToDefaults(saved)
        }
    }

    func remove(movie: Movie) {
        var saved = getFavourites()
        saved.removeAll { $0.id == movie.id }
        saveToDefaults(saved)
    }

    func getFavourites() -> [Movie] {
        guard let data = UserDefaults.standard.data(forKey: key),
              let movies = try? JSONDecoder().decode([Movie].self, from: data) else {
            return []
        }
        return movies
    }

    private func saveToDefaults(_ movies: [Movie]) {
        if let data = try? JSONEncoder().encode(movies) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}
