//
//  CDP_TMDBTests.swift
//  CDP-TMDBTests
//
//  Created by Techsevin on 08/07/25.
//

import Testing
@testable import CDP_TMDB

struct CDP_TMDBTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
